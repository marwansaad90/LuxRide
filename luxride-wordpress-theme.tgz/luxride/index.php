<?php
/**
 * Fallback template.
 *
 * @package LuxRide
 */

get_header();
get_template_part('template-parts/app-shell');
get_footer();
